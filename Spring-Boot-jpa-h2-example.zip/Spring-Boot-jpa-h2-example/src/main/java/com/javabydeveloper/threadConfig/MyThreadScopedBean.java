package com.javabydeveloper.threadConfig;

import com.javabydeveloper.model.User;
import com.javabydeveloper.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@Scope("prototype")
public class MyThreadScopedBean {
    // Bean properties and methods

    @Autowired
    DemoService demoService;

    public User getuser(Long id) {
        User user = demoService.getuser(id);
        return user;
    }
}

