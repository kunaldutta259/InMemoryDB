package com.javabydeveloper.threadConfig;

import com.javabydeveloper.model.User;
import com.javabydeveloper.util.DateTimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

@Component
public class MyThreadExecutor {
    //private final TaskExecutor taskExecutor;

    //private final AsyncTaskExecutor callableTaskExecutor;
    private final MyThreadScopedBean threadScopedBean;

    @Autowired
    SharedQueueConfig sharedQueueConfig;

    //private final MyCallable callable;

    @Autowired
    public MyThreadExecutor(MyThreadScopedBean threadScopedBean) {
        this.threadScopedBean = threadScopedBean;
        //startQueueProcessor();
    }
/*
    @Autowired
    public MyThreadExecutor(AsyncTaskExecutor taskExecutor, MyThreadScopedBean threadScopedBean) {
        this.callableTaskExecutor = taskExecutor;
        this.threadScopedBean = threadScopedBean;
    }
 */
/*
    public void executeRunnableThreads() {
        for (int i = 0; i < 10; i++) {
            taskExecutor.execute(new MyRunnable(threadScopedBean, (long) i));
        }
    }
*/
    //@Async()
    public void executeThreads() throws ExecutionException, InterruptedException {
        System.out.println(DateTimeUtil.getLocalDatetime() +
                "Executing MyThreadExecutor.execute on thread: " + Thread.currentThread().getName());

        //List<CompletableFuture<User>> futures = new ArrayList<>();
        //for (int i = 1; i <= 4; i++) {
            //Long id = sharedQueueConfig.sharedQueue().take();
            //System.out.println("executing thread: " + i);
            CompletableFuture<User> future = new MyCallable(threadScopedBean, sharedQueueConfig).callAsync();
            //futures.add(future);
            User result = future.get();
            System.out.println(DateTimeUtil.getLocalDatetime() + "Result from thread: " + result);
        //}
/*
        List<User> users = new ArrayList<>();
        for (CompletableFuture<User> future : futures) {
            User user = future.get();
            users.add(user);
        }
        return users;

 */
    }
/*
    @Async
    public void startQueueProcessor() {
        while (true) {
            try {
                //int valueFromQueue = sharedQueue.take(); // Blocks until a value is available
                CompletableFuture<User> future = new MyCallable(threadScopedBean, sharedQueueConfig).callAsync();
                User result = future.get();
                System.out.println(" - Result: " + result);
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
    }

 */
    /*
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(AppConfig.class);
        MyThreadExecutor executor = context.getBean(MyThreadExecutor.class);
        executor.executeThreads();
        context.close();
    }

     */
}

