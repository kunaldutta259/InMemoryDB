package com.javabydeveloper.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.BlockingQueue;

import com.javabydeveloper.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.javabydeveloper.repository.UserRepository;
import com.javabydeveloper.model.User;
import com.javabydeveloper.threadConfig.SharedQueueConfig;

@RestController
@RequestMapping("/api/users")
public class UserController {

	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private DemoService demoService;
	@Autowired
	SharedQueueConfig sharedQueueConfig;

	/*
	  @GetMapping
	  public List<User> getAllUsers() {
	    return userRepository.findAll();
	  }
	  @GetMapping("/{id}")
	  public ResponseEntity<User> getUserById(@PathVariable(value = "id") Long userId){
	      
	    User user = userRepository.findById(userId)
	          .orElseThrow(() -> new NoSuchElementException("User not available for Id :"+userId));
	        
	    return ResponseEntity.ok().body(user);
	  }

	@GetMapping(value = "/test", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> testMethod()
	{
		List<Long> idList = new ArrayList<>();
		idList.add(1L);idList.add(2L);idList.add(3L);idList.add(4L);

		List<User> users = new ArrayList<>();

		for (Long l: idList){
			User user = demoService.getuser(l);
			users.add(user);
		}
		return users;
	}

	 */

	@GetMapping("/add-to-queue/{id}")
	public void addToQueue(@PathVariable(value = "id") Long id) throws InterruptedException {
		System.out.println("Starting addToQueue with " + id);
		BlockingQueue<Long> queue =
				sharedQueueConfig.sharedQueue();
		List<Long> idList = new ArrayList<>();
		for(long i = 1L; i <= 6L; i++){
			idList.add(i);
		}

		queue.addAll(idList);
		queue.forEach(System.out::println);
		//sharedQueue.put(value);
	}
}
