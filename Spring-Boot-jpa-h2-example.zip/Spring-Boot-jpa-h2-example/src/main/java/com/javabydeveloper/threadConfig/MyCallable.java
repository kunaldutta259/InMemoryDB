package com.javabydeveloper.threadConfig;

import com.javabydeveloper.model.User;
import com.javabydeveloper.util.DateTimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;

@Component
public class MyCallable implements Callable<User> {
    private final MyThreadScopedBean threadScopedBean;
    //private final long id;
    @Autowired
    SharedQueueConfig sharedQueueConfig;

    @Autowired
    public MyCallable(MyThreadScopedBean threadScopedBean, SharedQueueConfig sharedQueueConfig) {
        this.threadScopedBean = threadScopedBean;
        this.sharedQueueConfig = sharedQueueConfig;
        //this.id = id;
    }

    @Override
    public User call() throws InterruptedException {
        // Use threadScopedBean in a thread-safe manner

        User user = threadScopedBean.getuser(sharedQueueConfig.sharedQueue().take());
        return user;
    }

    //@Async()
    public CompletableFuture<User> callAsync() throws InterruptedException {
        System.out.println(DateTimeUtil.getLocalDatetime() +
                "Executing MyCallable.callAsync on thread: " + Thread.currentThread().getName());

        sharedQueueConfig.sharedQueue().forEach(System.out::println);
        User user = threadScopedBean.getuser(sharedQueueConfig.sharedQueue().take());
        //System.out.println("Thread: " + Thread.currentThread().getName() + " - User: " + user);
        return CompletableFuture.completedFuture(user);
    }
}

