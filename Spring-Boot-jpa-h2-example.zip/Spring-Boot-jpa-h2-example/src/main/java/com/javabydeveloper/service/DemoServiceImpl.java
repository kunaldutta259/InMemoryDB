package com.javabydeveloper.service;

import com.javabydeveloper.model.User;
import com.javabydeveloper.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DemoServiceImpl implements DemoService{

    @Autowired
    UserRepository userRepository;
    @Override
    public List<User> testService() {
        List<User> users = new ArrayList<>();
        users = userRepository.findAll();
        return users;
    }

    @Override
    public User getuser(Long id) {
        Optional<User> optionalUser = userRepository.findById(id);
        return optionalUser.orElse(null);
    }
}
