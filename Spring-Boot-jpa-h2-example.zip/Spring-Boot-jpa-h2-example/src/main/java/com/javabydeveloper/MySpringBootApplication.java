package com.javabydeveloper;

import java.util.Date;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.javabydeveloper.repository.UserRepository;

import com.javabydeveloper.model.User;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableAsync
public class MySpringBootApplication {

	
	@Autowired
	  private UserRepository userRepository;
	  public static void main(String[] args) {
	    SpringApplication.run(MySpringBootApplication.class, args);
	  }

	  // spring calls after the initialization of bean properties
	  @PostConstruct
	  private void initDb() {
			User user0 = new User();
			//user.setUserType(UserType.STUDENT);
			user0.setUserName("PeterM0");
			user0.setPassword("ABC123abc*");
			user0.setDateofBirth(new Date());
			user0.setCreationTime(new Date());
			userRepository.save(user0);

		  User user1 = new User();
		  //user.setUserType(UserType.STUDENT);
		  user1.setUserName("PeterM1");
		  user1.setPassword("ABC123abc*");
		  user1.setDateofBirth(new Date());
		  user1.setCreationTime(new Date());
		  userRepository.save(user1);

		  User user2 = new User();
		  //user.setUserType(UserType.STUDENT);
		  user2.setUserName("PeterM2");
		  user2.setPassword("ABC123abc*");
		  user2.setDateofBirth(new Date());
		  user2.setCreationTime(new Date());
		  userRepository.save(user2);

		  User user3 = new User();
		  //user.setUserType(UserType.STUDENT);
		  user3.setUserName("PeterM3");
		  user3.setPassword("ABC123abc*");
		  user3.setDateofBirth(new Date());
		  user3.setCreationTime(new Date());
		  userRepository.save(user3);

		  User user4 = new User();
		  //user.setUserType(UserType.STUDENT);
		  user4.setUserName("PeterM4");
		  user4.setPassword("ABC123abc*");
		  user4.setDateofBirth(new Date());
		  user4.setCreationTime(new Date());
		  userRepository.save(user4);

		  User user5 = new User();
		  //user.setUserType(UserType.STUDENT);
		  user5.setUserName("PeterM5");
		  user5.setPassword("ABC123abc*");
		  user5.setDateofBirth(new Date());
		  user5.setCreationTime(new Date());
		  userRepository.save(user5);
	  }

}
