package com.javabydeveloper.service;

import com.javabydeveloper.model.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DemoService {

    List<User> testService();

    User getuser(Long id);
}
