/*
package com.javabydeveloper.threadConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MyRunnable implements Runnable {
    private final MyThreadScopedBean threadScopedBean;
    private final Long id;

    @Autowired
    public MyRunnable(MyThreadScopedBean threadScopedBean, Long id) {
        this.threadScopedBean = threadScopedBean;
        this.id = id;
    }

    @Override
    public void run() {
        // Use threadScopedBean in a thread-safe manner
        threadScopedBean.getuser(id);
    }
}

 */

