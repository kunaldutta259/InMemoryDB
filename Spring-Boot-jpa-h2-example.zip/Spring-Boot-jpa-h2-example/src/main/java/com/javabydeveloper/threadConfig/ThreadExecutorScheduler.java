package com.javabydeveloper.threadConfig;

import com.javabydeveloper.util.DateTimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;

@Component
public class ThreadExecutorScheduler {

    private final MyThreadExecutor threadExecutor;

    @Autowired
    public ThreadExecutorScheduler(MyThreadExecutor threadExecutor) {
        System.out.println(DateTimeUtil.getLocalDatetime() + "ThreadExecutorScheduler constructor executed");
        this.threadExecutor = threadExecutor;
    }

    @Bean
    public ThreadPoolTaskScheduler threadPoolTaskScheduler() {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(3); // Number of threads in the pool
        scheduler.setThreadNamePrefix("MySchedulerThread-");
        return scheduler;
    }

    @Scheduled(fixedRate = 1000) // Execute every 1 seconds
    @Async("threadPoolTaskScheduler")
    public void startThreadExecutor() throws ExecutionException, InterruptedException {
        System.out.println(DateTimeUtil.getLocalDatetime() +
                "Running ThreadExecutorScheduler.startThreadExecutor");
        threadExecutor.executeThreads();
    }
}

