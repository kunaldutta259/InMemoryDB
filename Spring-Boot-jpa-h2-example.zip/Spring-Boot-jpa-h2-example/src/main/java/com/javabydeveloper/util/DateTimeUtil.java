package com.javabydeveloper.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimeUtil {

    public static String getLocalDatetime() {
        // Get the current local date and time
        LocalDateTime currentDateTime = LocalDateTime.now();

        // Define a formatter for the desired output format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // Format the current local date and time using the formatter
        String formattedDateTime = currentDateTime.format(formatter);

        return formattedDateTime + ": ";
    }
}
