package com.javabydeveloper.threadConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

@Configuration
public class SharedQueueConfig {

   //public static BlockingQueue<Long> sharedQueue;




    @Bean
    public BlockingQueue<Long> sharedQueue() {
        System.out.println("returning new Queue instance");
        return new LinkedBlockingQueue<>();
    }

}

